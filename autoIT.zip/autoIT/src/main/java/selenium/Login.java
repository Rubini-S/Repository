package selenium;

public class Login {

	public static final String username="XXXXXXXXXXXXXX";
	public static final String password="XXXXXXXXXX";
}

