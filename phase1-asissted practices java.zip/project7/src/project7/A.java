package project7;


	class A{
		   public void methodA()
		   {
		     System.out.println("Base class method");
		   }
		   }

		